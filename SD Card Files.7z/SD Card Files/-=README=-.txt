=============================================================================
4-20mA Data Logger
Records 4 channels of 4-20mA data to a CSV file on attached SD card if any channel changes more than than the channels programmed deadband (up or down).


Copy all files on this SD Card locally in order to save everything in case you need to use another SD card.
=============================================================================
SD Card Contents:
\DATA Folder
	Contains saved data from logger in CSV format
	logger creates 1MB files in the format: DATAX.CSV where X is a sequential number
	You can delete any files created in this folder.  The logger will create them as required
\MENU
	Contains the text that is displayed when using the data port
	Do not move or modify any files in this folder
\Install Files
   	\Arduino IDE
	   Contains a copy of the Arduino IDE that one can use to access the Data port using the Serial Monitor
	\Firmware
		Contains a copy of the source code or "firmware" used for the Data logger.  You can use the Arduino IDE
		  to download the firmware
		\_4-20mA_Data_Logger_init.ino
			Run this file to initialize the data logger to factory default settings
			This file was needed due to space constraints in the microcontroller
		\_4-20mA_Data_Logger.ino
			The source code running on the data logger
	\USB Drivers CH340
		Drivers for the USB to serial converter used on the data port.  Windows does not automatically install this device
	\_4-20mA_Data_Logger_Schematic.pdf
		Schematic used in the data logger.  Provided here for completeness and to assist with future troubleshooting



